package com.tracker.tasktracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskTrackerSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
