package com.tracker.tasktracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskTrackerSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskTrackerSystemApplication.class, args);
	}

}
